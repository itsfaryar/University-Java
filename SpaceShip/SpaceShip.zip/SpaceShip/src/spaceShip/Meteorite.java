package spaceShip;

public class Meteorite {
	public Position pos;
	public Position virtual_pos;
	public double speed;
	public Meteorite() {
		this.pos=new Position();
		this.virtual_pos=new Position();
		
	}
	
}
